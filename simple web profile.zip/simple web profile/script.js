document.addEventListener("DOMContentLoaded", function() {
    const body = document.querySelector("body");

    // Saat cursor masuk ke dalam body
    body.addEventListener("mouseenter", function() {
        body.style.backdropFilter = "none"; // Menghapus efek blur
    });

    // Saat cursor keluar dari body
    body.addEventListener("mouseleave", function() {
        body.style.backdropFilter = "blur(5px)"; // Menambahkan kembali efek blur
    });
});
